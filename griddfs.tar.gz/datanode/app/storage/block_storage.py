import os
import hashlib
import json
from pathlib import Path
from typing import Dict, List, Optional
from fastapi import HTTPException
import aiofiles

class BlockStorage:
    def __init__(self, storage_path: str = "/app/storage"):
        self.storage_path = Path(storage_path)
        self.storage_path.mkdir(parents=True, exist_ok=True)
        self.metadata_file = self.storage_path / "blocks_metadata.json"
        self.metadata = self._load_metadata()
    
    def _load_metadata(self) -> Dict:
        if self.metadata_file.exists():
            try:
                with open(self.metadata_file, 'r') as f:
                    return json.load(f)
            except (json.JSONDecodeError, FileNotFoundError):
                return {"blocks": {}}
        return {"blocks": {}}
    
    def _save_metadata(self):
        with open(self.metadata_file, 'w') as f:
            json.dump(self.metadata, f, indent=2)
    
    def _get_block_path(self, block_id: str) -> Path:
        return self.storage_path / f"block_{block_id}.dat"
    
    def _calculate_checksum(self, data: bytes) -> str:
        return hashlib.sha256(data).hexdigest()
    
    async def store_block(self, block_id: str, data: bytes, checksum: str) -> bool:
        """Almacenar un bloque con verificación de checksum"""
        try:
            # Verificar checksum
            calculated_checksum = self._calculate_checksum(data)
            if calculated_checksum != checksum:
                return False
            
            block_path = self._get_block_path(block_id)
            
            async with aiofiles.open(block_path, 'wb') as f:
                await f.write(data)
            
            # Guardar metadatos
            import time
            self.metadata["blocks"][block_id] = {
                "size": len(data),
                "checksum": checksum,
                "created_at": str(time.time()),
                "path": str(block_path)
            }
            
            self._save_metadata()
            return True
            
        except Exception:
            return False
    
    async def retrieve_block(self, block_id: str) -> Optional[bytes]:
        """Recuperar un bloque"""
        if block_id not in self.metadata["blocks"]:
            return None
        
        try:
            block_path = self._get_block_path(block_id)
            if not block_path.exists():
                return None
            
            async with aiofiles.open(block_path, 'rb') as f:
                data = await f.read()
            
            return data
        except Exception:
            return None
    
    async def delete_block(self, block_id: str) -> bool:
        """Eliminar un bloque"""
        if block_id not in self.metadata["blocks"]:
            return False
        
        try:
            block_path = self._get_block_path(block_id)
            if block_path.exists():
                block_path.unlink()
            
            del self.metadata["blocks"][block_id]
            self._save_metadata()
            return True
        except Exception:
            return False
    
    async def get_block_info(self, block_id: str) -> Optional[Dict]:
        """Obtener información de un bloque"""
        if block_id not in self.metadata["blocks"]:
            return None
        
        block_info = self.metadata["blocks"][block_id].copy()
        block_info["block_id"] = block_id
        return block_info
    
    async def list_blocks(self) -> List[Dict]:
        """Listar todos los bloques"""
        blocks = []
        for block_id, metadata in self.metadata["blocks"].items():
            block_info = metadata.copy()
            block_info["block_id"] = block_id
            blocks.append(block_info)
        return blocks
    
    def get_storage_usage(self) -> Dict:
        """Obtener información de uso de almacenamiento"""
        total_blocks = len(self.metadata["blocks"])
        total_size = sum(block["size"] for block in self.metadata["blocks"].values())
        
        return {
            "total_size": total_size,
            "block_count": total_blocks,
            "storage_path": str(self.storage_path)
        }