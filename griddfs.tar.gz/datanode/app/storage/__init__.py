"""
Storage module for DataNode
"""
from .block_storage import BlockStorage

__all__ = ["BlockStorage"]
